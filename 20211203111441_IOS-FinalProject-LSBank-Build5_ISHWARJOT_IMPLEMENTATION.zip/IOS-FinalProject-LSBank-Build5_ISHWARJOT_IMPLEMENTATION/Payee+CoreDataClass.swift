//
//  Payee+CoreDataClass.swift
//  IOS-FinalProject-LSBank
//
//  Created by Daniel Carvalho on 14/11/21.
//
//

import Foundation
import CoreData

@objc(Payee)
public class Payee: NSManagedObject {

}
